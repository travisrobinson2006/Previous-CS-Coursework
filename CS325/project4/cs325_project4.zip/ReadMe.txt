**************************************ReadMe************************************
Before running this program, it must be compiled by entering at the command line:
g++ cs_325_project4.cpp -o [name_you_would_like_to_call_it] where you insert the 
name you wish. (Alternatively, don't include a name and the default will be a.out)
From there, use the program by calling on the name you would like to call it and 
including the .txt file you wish to run. For example, if you call it group_6, 
and your .txt file was called example_1, you would enter at the command line
group_6 example_1.txt
This will produce an output file called example_1.txt.tour which is the
certificate for the TSP problem.
************************************End ReadMe**********************************
