README-How To Use CS325_Project1 For Group 6
********************************************
Ensure that the file MSS_Problems.txt is in
the same directory as CS325_Project1.cpp
Compile CS325_Project1.cpp using FLIP Server
Run compiled program, results will be output
to MSS_Results.txt
********************************************
